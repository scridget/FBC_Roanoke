"use strict";

window.jQuery = window.$ = jQuery;

jQuery(document).ready(function($) {
	"use strict";
});
